package com.example.demo.controllers;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.example.demo.entities.Product;
import com.example.demo.services.ProductServices;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@Controller
@Tag(name = "Product Controller", description = "Endpoints for managing dining products")
public class ProductController 
{
	@Autowired
	private ProductServices productServices;

	//	AddProduct
	@PostMapping("/addingProduct")
	@Operation(summary = "Create a product", description = "Adds a new food item to the catalog")
	public String addProduct(@ModelAttribute Product product)
	{

		this.productServices.addProduct(product);
		return "redirect:/admin/services";
	}

	//	UpdateProduct
	@GetMapping("/updatingProduct/{productId}")
	@Operation(summary = "Update a product", description = "Modifies an existing food item's details")
	public String updateProduct(@ModelAttribute Product product,@PathVariable("productId") int id)
	{

		this.productServices.updateproduct(product, id);
		return "redirect:/admin/services";
	}
	//DeleteProduct
	@GetMapping("/deleteProduct/{productId}")
	@Operation(summary = "Delete a product", description = "Removes a food item from the menu by ID")
	public String delete(@PathVariable("productId") int id)
	{
		this.productServices.deleteProduct(id);
		return "redirect:/admin/services";
	}
	
}